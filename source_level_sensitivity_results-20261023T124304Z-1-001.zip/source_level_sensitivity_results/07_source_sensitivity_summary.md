# RAID source-level sensitivity analysis

Input: raid_chatgpt_linguistic_features_v2.csv
Original rows: 26,742; distinct sources: 13,371
Paired attacked rows: 294,162; pairing coverage: 100.00%
Paired differences: attacked minus original; source differences are the mean of valid original-level differences per source.
Wilcoxon and paired t-test p-values were adjusted with BH separately across eight features per attack/scope.

## Overall attack-level
Compared features: 88
FDR-valid in both analyses: 88
FDR-significant comparisons: document = 48, source = 48
Changed Wilcoxon significance decisions = 0
Changed d_z directions = 0
Median |d_z|: document = 0.0856, source = 0.0980

## Attack-domain-level
Compared features: 704
FDR-valid in both analyses: 704
FDR-significant comparisons: document = 371, source = 366
Changed Wilcoxon significance decisions = 5
Changed d_z directions = 0
Median |d_z|: document = 0.0571, source = 0.0709

## Interpretation guidance
These statistics examine sensitivity to repeated sources; they do not establish statistical equivalence or detector accuracy.
Report substantive changes in FDR decisions, direction, and effect magnitude; if differences are large, revisit the main statistical interpretation.